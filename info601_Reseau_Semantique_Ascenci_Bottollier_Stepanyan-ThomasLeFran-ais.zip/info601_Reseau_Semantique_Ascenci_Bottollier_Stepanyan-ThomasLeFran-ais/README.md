# info601_Reseau_Semantique_Ascenci_Bottollier_Stepanyan
Projet réalisé au cours du TP d'Info601.

## constantes/

### ConstantesBasiques.java
Toutes les constantes du projet sont définies ici.

## gestion_erreurs/

## lisibilite_code/

### ActionConsole.java
Facilite la lecture de la classe MainConsole.

## main/

### MainConsole.java
Classe principale de l'application.
Elle se charge de l'interaction entre l'utilisateur
et le modèle.

## modele/

### Graphe.java
Représentation d'un graphe.

### Noeud.java
Représentation d'un noeud.
