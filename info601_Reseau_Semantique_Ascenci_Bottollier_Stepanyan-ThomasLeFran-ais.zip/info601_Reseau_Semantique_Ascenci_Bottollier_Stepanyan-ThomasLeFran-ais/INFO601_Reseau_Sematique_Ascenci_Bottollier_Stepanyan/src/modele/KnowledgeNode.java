package modele;

import java.util.ArrayList;
import java.util.Date;


public class KnowledgeNode extends Node {
	
	public Date releaseDate;
	public String socket;
	public String ram;
	public ArrayList<Relation> isAList = new ArrayList<>();
	public ArrayList<Relation> isModelOfList = new ArrayList<>();
	public ArrayList<Relation> isQuadCoreList = new ArrayList<>();
	
	public ArrayList<Relation> getIsARelations(){
		return isAList;
	}
	
	public ArrayList<Relation> getIsModelOfRelations(){
		return isModelOfList;
	}
	
	public ArrayList<Relation> getIsQuadCoreRelations(){
		return isQuadCoreList;
	}

}
