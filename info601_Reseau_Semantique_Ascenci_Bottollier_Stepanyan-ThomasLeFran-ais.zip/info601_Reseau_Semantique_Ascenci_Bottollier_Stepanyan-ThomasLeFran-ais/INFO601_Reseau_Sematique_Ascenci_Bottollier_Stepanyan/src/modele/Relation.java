package modele;

public class Relation {
	public enum RelationType { isA, isModelOf, isQuadCore };
	public RelationType relationType;
	
	public Relation(RelationType relationType) {
		this.relationType = relationType;
	}

}
