package modele;

import java.util.ArrayList;

public class Node {
	public String name;
	public int degree;
	
	public ArrayList<Node> getPrec() {
		
		
	}

}
