package constantes;

public class ConstantesBasiques {
	public static final String CONSOLE_SEPARATOR = "######################################";
}
